﻿using Entities.Models;
using System.Collections.Generic;

namespace Business.Interfaces
{
    public interface IStudent
    {
        Student Create(Student student, string groupName);
        Student Delete(int id);
        Student Update(Student student, string groupName);
        Student Get(int id);
        List<Student> Get(string name);
        List<Student> GetAll(string groupName);
        List<Student> GetAll();

    }
}
