﻿using Business.Services;
using Entities.Models;
using System;
using System.Collections.Generic;
using System.Text;
using Utilies.Helpers;

namespace AcademyApp.Controllers
{
    public class StudentController
    {
        private StudentService studentService { get; }
        public StudentController()
        {
            studentService = new StudentService();
        }
        public void Create()
        {
            Helper.ChangeTextColor(ConsoleColor.Blue, "Select possible group:");
            string groupName = Console.ReadLine();
            Helper.ChangeTextColor(ConsoleColor.Blue, "Enter student name:");
            string name = Console.ReadLine();
            Helper.ChangeTextColor(ConsoleColor.Blue, "Enter student surname:");
            string surname = Console.ReadLine();
            Student student = new Student { Name = name, Surname = surname };
            Student newStu = studentService.Create(student, groupName);
            if (newStu != null)
            {
                Helper.ChangeTextColor(ConsoleColor.Green, 
                    $"New Student is Created - {newStu.Name} {newStu.Surname}");
                return;
            }
            Helper.ChangeTextColor(ConsoleColor.Red,
                $"Couldn't find such as Group - {groupName}");
        }
        public void GetAllStudentWithGroup()
        {
            Helper.ChangeTextColor(ConsoleColor.Blue, "Select possible group:");
            string groupName = Console.ReadLine();
            List<Student> students = studentService.GetAll(groupName);
            if (students != null)
            {
                Helper.ChangeTextColor(ConsoleColor.Blue, $"Group {groupName}:");
                foreach (var item in students)
                {
                    Helper.ChangeTextColor(ConsoleColor.Green,
                    $"{item.Id} - {item.Name} {item.Surname}");
                }
                return;
            }
            Helper.ChangeTextColor(ConsoleColor.Red,
                $"Couldn't find such as Group - {groupName}");
        }
    }
}
