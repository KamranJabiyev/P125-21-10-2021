﻿using Entities.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace DataAccess
{
    public static class DbContext
    {
        public static List<Student> Students { get; }
        public static List<Group> Groups { get; }
        static DbContext()
        {
            Students = new List<Student>();
            Groups = new List<Group>();
        }
    }
}
