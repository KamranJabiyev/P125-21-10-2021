﻿using DataAccess.Interfaces;
using Entities.Models;
using System;
using System.Collections.Generic;

namespace DataAccess.Repositories
{
    public class StudentRepository : IRepository<Student>
    {
        public bool Create(Student entity)
        {
            try
            {
                DbContext.Students.Add(entity);
                return true;
            }
            catch (Exception)
            {

                throw;
            }
        }

        public bool Delete(Student entity)
        {
            try
            {
                DbContext.Students.Remove(entity);
                return true;
            }
            catch (Exception)
            {

                throw;
            }
        }

        public Student Get(Predicate<Student> filter = null)
        {
            try
            {
                return filter==null ? DbContext.Students[0]
                    : DbContext.Students.Find(filter);
            }
            catch (Exception)
            {
                throw;
            }
        }

        public List<Student> GetAll(Predicate<Student> filter = null)
        {
            try
            {
                return filter == null ? DbContext.Students
                    : DbContext.Students.FindAll(filter);
            }
            catch (Exception)
            {
                throw;
            }
        }

        public bool Update(Student entity)
        {
            try
            {
                Student dbStudent = Get(s => s.Id == entity.Id);
                dbStudent = entity;
                return true;
            }
            catch (Exception)
            {

                throw;
            }
        }
    }
}
