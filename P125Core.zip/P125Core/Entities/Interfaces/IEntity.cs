﻿
namespace Entities.Interfaces
{
    public interface IEntity
    {
        public int Id { get; set; }
    }
}
